/**
 * this is the monster class
 */
public class Monster {
    String name;

    /**
     *
     * @param name contains the monsters name
     */
    public Monster(String name) {
        this.name = name;
    }
}
